﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AppdevTakeHomeW14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        DataTable dtMatch;
        DataTable dtJumlahMatch;
        DataTable dtTeamHome;
        DataTable dtTeamAway;
        DataTable dtAdd;
        string query;
        string matchID;
        string tAway;
        string tHome;

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox_matchID.Enabled = false;
            dtMatch = new DataTable();
            sqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=Dwinda1408;database=premier_league");
            sqlConnection.Open();
            query = "SELECT * FROM `match`;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            SqlDataAdapter.Fill(dtMatch);

            query = "SELECT team_name, team_id FROM team ;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtTeamHome = new DataTable();
            SqlDataAdapter.Fill(dtTeamHome);
            comboBox_teamHome.DataSource = dtTeamHome;
            comboBox_teamHome.DisplayMember = "team_name";
            comboBox_teamHome.ValueMember = "team_id";

            dtTeamAway = new DataTable();
            SqlDataAdapter.Fill(dtTeamAway);
            comboBox_teamAway.DataSource = dtTeamAway;
            comboBox_teamAway.DisplayMember = "team_name";
            comboBox_teamAway.ValueMember = "team_id";

            comboBox_type.Items.Add("GO");
            comboBox_type.Items.Add("GP");
            comboBox_type.Items.Add("GW");
            comboBox_type.Items.Add("CR");
            comboBox_type.Items.Add("CY");
            comboBox_type.Items.Add("PM");

            dtAdd = new DataTable();
            dtAdd.Columns.Add("minute");
            dtAdd.Columns.Add("team");
            dtAdd.Columns.Add("player");
            dtAdd.Columns.Add("type");
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            var date = new DateTime(2015, 2, 16);
            if (dateTimePicker1.Value < date)
            {
                MessageBox.Show("Error");
            }
            query = $"SELECT match_id FROM `match` WHERE match_id like '{dateTimePicker1.Value.Year}%';";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtJumlahMatch = new DataTable();
            SqlDataAdapter.Fill(dtJumlahMatch);
            int jumlahMatch = dtJumlahMatch.Rows.Count;
            matchID = dateTimePicker1.Value.Year.ToString() + (jumlahMatch + 1).ToString().PadLeft(3, '0');
            textBox_matchID.Text = matchID;
        }

        private void comboBox_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_teamHome.SelectedValue != null && comboBox_teamAway.SelectedValue != null)
            {
                tHome = comboBox_teamHome.SelectedValue.ToString();
                tAway = comboBox_teamAway.SelectedValue.ToString();
                query = $"SELECT team_name, team_id from team where team_id = '{tHome}' OR team_id = '{tAway}';";
                sqlCommand = new MySqlCommand(query, sqlConnection);
                SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dtTeam = new DataTable();
                SqlDataAdapter.Fill(dtTeam);
                comboBox_team.DataSource = dtTeam;
                comboBox_team.DisplayMember = "team_name";
                comboBox_team.ValueMember = "team_id";
                //if (comboBox_teamHome.SelectedValue.ToString() == comboBox_teamAway.SelectedValue.ToString())
                //{
                //    MessageBox.Show("gak boleh sama!");
                //}
            }
        }

        private void comboBox_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_teamHome.SelectedValue != null && comboBox_teamAway.SelectedValue != null)
            {
                tHome = comboBox_teamHome.SelectedValue.ToString();
                tAway = comboBox_teamAway.SelectedValue.ToString();
                query = $"SELECT team_name, team_id from team where team_id = '{tHome}' OR team_id = '{tAway}';";
                sqlCommand = new MySqlCommand(query, sqlConnection);
                SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dtTeam = new DataTable();
                SqlDataAdapter.Fill(dtTeam);
                comboBox_team.DataSource = dtTeam;
                comboBox_team.DisplayMember = "team_name";
                comboBox_team.ValueMember = "team_id";

                if (comboBox_teamHome.SelectedValue.ToString() == comboBox_teamAway.SelectedValue.ToString())
                {
                    MessageBox.Show("gak boleh sama!");
                }
            }
        }

        private void comboBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = $"SELECT player_name, player_id from player where team_id = '{tHome}' OR team_id = '{tAway}';";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dtTeam = new DataTable();
            SqlDataAdapter.Fill(dtTeam);
            comboBox_player.DataSource = dtTeam;
            comboBox_player.DisplayMember = "player_name";
            comboBox_player.ValueMember = "player_id";
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if(comboBox_teamHome.Text == comboBox_teamAway.Text)
            {
                MessageBox.Show("Team Home dan Team Away tidak boleh sama");
            }
            else if(textBox_minute.Text == "" || comboBox_team.Text == "" || comboBox_player.Text == "" || comboBox_type.Text == "")
            {
                MessageBox.Show("Isi dulu donggg");
            }
            else
            {
                dtAdd.Rows.Add(textBox_minute.Text, comboBox_team.Text, comboBox_player.Text, comboBox_type.Text);
                dataGridView1.DataSource = dtAdd;
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            dtAdd.Rows.RemoveAt(dataGridView1.CurrentCell.RowIndex);
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dtAdd.Rows.Count; i++)
                {
                    string matchid = textBox_matchID.Text;
                    string matchdate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                    string teamHomeId = comboBox_teamHome.SelectedValue.ToString();
                    string teamAwayId = comboBox_teamAway.SelectedValue.ToString();
                    string refereeId = "M002";
                    int goalHome = 0;
                    int goalAway = 0;

                    foreach (DataRow row in dtAdd.Rows)
                    {
                        if (row["Team"].ToString() == comboBox_teamHome.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalHome++;
                        }
                    }
                    foreach (DataRow row in dtAdd.Rows)
                    {
                        if (row["Team"].ToString() == comboBox_teamAway.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalAway++;
                        }
                    }

                    // Insert into `match` table
                    string query = $"INSERT INTO `match` (match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, `delete`) VALUES (@match_id, @match_date, @team_home, @team_away, @goal_home, @goal_away, @referee_id, @delete)";
                    using (MySqlCommand sqlCommand = new MySqlCommand(query, sqlConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@match_id", matchid);
                        sqlCommand.Parameters.AddWithValue("@match_date", matchdate);
                        sqlCommand.Parameters.AddWithValue("@team_home", teamHomeId);
                        sqlCommand.Parameters.AddWithValue("@team_away", teamAwayId);
                        sqlCommand.Parameters.AddWithValue("@goal_home", goalHome);
                        sqlCommand.Parameters.AddWithValue("@goal_away", goalAway);
                        sqlCommand.Parameters.AddWithValue("@referee_id", refereeId);
                        sqlCommand.Parameters.AddWithValue("@delete", 0); 
                        sqlCommand.ExecuteNonQuery();
                    }

                    // Insert into dmatch table
                    query = "INSERT INTO dmatch (match_id, minute, team_id, player_id, type, `delete`) VALUES (@match_id, @minute, @team_id, @player_id, @type, @delete)";
                    using (MySqlCommand sqlCommand = new MySqlCommand(query, sqlConnection))
                    {
                        sqlCommand.Parameters.AddWithValue("@match_id", textBox_matchID.Text.ToString());
                        sqlCommand.Parameters.AddWithValue("@minute", textBox_minute.Text);
                        sqlCommand.Parameters.AddWithValue("@team_id", comboBox_team.SelectedValue.ToString());
                        sqlCommand.Parameters.AddWithValue("@player_id", comboBox_player.SelectedValue.ToString());
                        sqlCommand.Parameters.AddWithValue("@type", comboBox_type.Text);
                        sqlCommand.Parameters.AddWithValue("@delete", 0); 
                        sqlCommand.ExecuteNonQuery();
                    }

                    MessageBox.Show("Berhasil insert");
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("SQL Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (sqlConnection.State == System.Data.ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }
    }
}
